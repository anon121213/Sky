#include "skypch.h"
#include "RendererAPI.h"

namespace Sky {

	RendererAPI::API RendererAPI::s_API = RendererAPI::API::OpenGL;



}